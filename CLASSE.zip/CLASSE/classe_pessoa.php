<?php
require_once 'pessoa.php';

$pessoa = new Pessoa();
$pessoa->idade = 30;
$pessoa->nome = 'Enzo';

$pessoa->falar();
$pessoa->simulacomer();
$pessoa->caminhar();
$pessoa->apresentar();
$pessoa->simuladormir();
?>