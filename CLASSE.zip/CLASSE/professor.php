<?php
class Professor {
    protected $salario;
    public $nome;
    public $disciplina;
    private $cpf;

    public function ensinar() {
        echo "$this->nome está ensinando.<br>";
    }
    
    public function corrigirProva() {
        echo "$this->nome está corrigindo prova.<br>";
    }
    
    public function prepararAula() {
        echo "$this->nome está preparando aula.<br>";
    }
    
    private function fazerChamada() {
        echo "$this->nome está fazendo chamada.<br>";
    }
    
    private function corrigirTarefa() {
        echo "$this->nome está corrigindo tarefa.<br>";
    }

    public function simulaCorrigirTarefa(){
        $this-> corrigirTarefa();
    }

    public function simulaFazerChamada(){
        $this-> fazerChamada();
    }
}
?>
