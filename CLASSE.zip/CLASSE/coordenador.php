<?php
class Coordenador {
    public $nome;
    protected $salario;
    private $cpf;
    public $departamento;

    public function coordenarTurmas() {
        echo "$this->nome está coordenando turmas.<br>";
    }
    
    public function auxiliarProfessores() {
        echo "$this->nome está auxiliando professore.s<br>";
    }
    
    public function planejarAulas() {
        echo "$this->nome está planejando aulas.<br>";
    }
    
    private function definirHorarios() {
        echo "$this->nome está definindo horários.<br>";
    }
    
    private function organizarReunioes() {
        echo "$this->nome está organizando reuniões.<br>";
    }

    public function simuladefinirhora(){
        $this-> definirHorarios();
    }

    public function simulaOrganizarReuniao(){
        $this-> organizarReunioes();
    }
}
?>
