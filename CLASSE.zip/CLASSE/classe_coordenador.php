<?php
require_once 'coordenador.php';

$coordenador = new Coordenador();
$coordenador->nome = 'Melina';
$coordenador->departamento = 'SESI 428';

$coordenador->coordenarTurmas();
$coordenador->auxiliarProfessores();
$coordenador->planejarAulas();
$coordenador->simuladefinirhora();
$coordenador->simulaOrganizarReuniao();
?>
