<?php
require_once 'professor.php';

$professor = new Professor();
$professor->nome = 'Andreia';
$professor->disciplina = 'Matemática';

$professor->ensinar();
$professor->corrigirProva();
$professor->prepararAula();
$professor->simulaFazerChamada();
$professor->simulacorrigirTarefa();
?>