<?php
class Pessoa {
    public $idade;
    protected $cpf;
    public $nome;
    protected $endereco;

    public function falar() {
        echo "$this->nome está falando.<br>";
    }

    private function comer() {
        echo "$this->nome está comendo.<br>";
    }

    public function simulacomer(){
        $this-> comer();
    }

    public function caminhar() {
        echo "$this->nome está caminhando.<br>";
    }

    public function apresentar() {
        echo "$this->nome está se apresentando.<br>";
    }

    private function dormir() {
        echo "$this->nome está dormindo.<br>";
    }

    public function simuladormir(){
        $this-> dormir();
    }
}
?>